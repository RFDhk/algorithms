import edu.princeton.cs.algs4.In;

import java.util.Arrays;

public class FastCollinearPoints {
    private static final double EPSILON = 1e-12;

    private final LineSegment[] segments;

    // finds all line segments containing 4 or more points
    public FastCollinearPoints(Point[] points) {

        for (int i = 0; i < points.length; i++) {
            if (points[i] == null) {
                throw new IllegalArgumentException("null " + i);
            }
            for (int j = i; j > 0; j--) {
                if (points[j].compareTo(points[j - 1]) < 0) {
                    Point p = points[j - 1];
                    points[j - 1] = points[j];
                    points[j] = p;
                } else if ((points[j].compareTo(points[j - 1]) == 0)) {
                    throw new IllegalArgumentException("duplicate");
                } else {
                    break;
                }
            }
        }


        LineSegment[] auxSegments = new LineSegment[points.length];
        int segmentsCount = 0;
        for (int i = 0; i < points.length - 2; i++) {
            Point center = points[i];
            double[] slopes = new double[points.length - i - 1];
            int indexes[] = new int[points.length - i - 1];
            for (int j = i + 1; j < points.length; j++) {
                slopes[j - i - 1] = center.slopeTo(points[j]);
                indexes[j - i - 1] = j;
            }

            for (int v = 0; v < slopes.length; v++) {
                for (int j = v; j > 0; j--) {
                    if (slopes[j] < slopes[j - 1]) {
                        double d = slopes[j - 1];
                        int index = indexes[j-1];
                        slopes[j - 1] = slopes[j];
                        indexes[j - 1] = indexes[j];
                        slopes[j] = d;
                        indexes[j] = index;
                    } else {
                        break;
                    }
                }
            }

            int count = 1;
            double curSlope = slopes[0];
            for (int n = 1; n < slopes.length; n++) {
                if (equalD(curSlope, slopes[n])) {
                    count++;
                } else {
                    if (count >= 3) {
                        auxSegments[segmentsCount++] = new LineSegment(points[i], points[indexes[n - 1]]);
                    }
                    count = 1;
                    curSlope = slopes[n];
                }
            }
        }

        segments = new LineSegment[segmentsCount];
        System.arraycopy(auxSegments, 0, segments, 0, segmentsCount);
    }

    // the number of line segments
    public int numberOfSegments() {
        return segments.length;
    }

    // the line segments
    public LineSegment[] segments() {
        return Arrays.copyOf(segments, segments.length);
    }

    private boolean equalD(double d1, double d2) {
        return (Math.abs(d1 - d2) < EPSILON);
    }

    public static void main(String[] args) {
        In in = new In("input8.txt");
        int count = in.readInt();
        Point[] points = new Point[count];
        for (int i = 0; i < points.length; i++) {
            points[i] = new Point(in.readInt(), in.readInt());
        }

        FastCollinearPoints b = new FastCollinearPoints(points);
        System.out.print(b.numberOfSegments());
    }
}
